#!/usr/local/bin/python2.7

from __future__ import print_function # Python 2/3 compatibility
from __future__ import division #Python 2/3 compatiblity for integer division
import argparse
import boto3
import csv
import time
import hashlib
import urllib
import json
import requests
from datetime import datetime, timedelta
from calendar import timegm

def shorten_url (url):
    endpoint = "https://api-ssl.bitly.com/v4/shorten"
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer 2fddedcc8e183aa986b8e89dc930fa49d8a9995e'
        }

    data = {
        'long_url': url
        }

    # sending post request and saving response as response object
    r = requests.post(url = endpoint, headers = headers, json = data)
    response = r.json()
    return response['link']

# command line arguments
parser = argparse.ArgumentParser(description='Write sessions CSV records to dynamo db table. CSV Header must map to dynamo table field names. Outputs a URL and QRCode image path fot feedback.')
parser.add_argument('csvFile', help='Path to csv file location')
parser.add_argument('table', default='sessions-feedback-dev-Sessions', nargs='?', help='Dynamo db table name. (default=sessions-feedback-dev-Sessions)')
parser.add_argument('writeRate', default=5, type=int, nargs='?', help='Number of records to write in table per second (default:5)')
parser.add_argument('delimiter', default=',', nargs='?', help='Delimiter for csv records (default=,)')
parser.add_argument('region', default='eu-west-1', nargs='?', help='Dynamo db region name (default=eu-west-1')
args = parser.parse_args()
print(args)
print('\n***********Sessions List ***********')

# dynamodb and table initialization
endpointUrl = "https://dynamodb." + args.region + ".amazonaws.com"
dynamodb = boto3.resource('dynamodb', region_name=args.region, endpoint_url=endpointUrl)
table = dynamodb.Table(args.table)
keys_list =['date_time', 'session_name', 'speaker', 'location', 'event_name']
# write records to dynamo db
with open(args.csvFile) as csv_file:
    tokens = csv.reader(csv_file, delimiter=args.delimiter)
    # read first line in file which contains dynamo db field names
    header = tokens.next();
    # rest of file contain new records
    for token in tokens:
       item = {}
       for i,val in enumerate(token):
         if val:
           key = header[i]
           if key =='date_time':
               ttl = int(time.mktime(time.strptime(val, '%Y-%m-%d %H:%M')))
               val = datetime.strptime(val, '%Y-%m-%d %H:%M')
               session_id_start = datetime.strftime(val, '%d')
               val = val.strftime("%B %d, %Y, %H:%M")

           if key == 'topic':
               session_id_end = val[:2].upper()

           if key in keys_list:
               if key=='public':
                 val = int(val)
               item[key.replace(" ", "").lower()] = val

       item['session_id'] = hashlib.md5(token[1] + token[4]).hexdigest()[:32].upper()
       #item['session_id'] = session_id_start + hashlib.md5(token[1] + token[4]).hexdigest()[:2].upper()
       item['ttl'] = ttl + (60*60*24*365)

       print ('\n%s by %s (%s)' % (item['session_name'], item['speaker'], item['date_time']))
       url = ('https://feedback.boaz.cloud?session_id=%s' % item['session_id'])
       short_url = shorten_url (url)
       print ('URL: %s' % short_url)
       print ('QR: https://api.qrserver.com/v1/create-qr-code/?data=%s&size=800x800' % urllib.quote_plus(short_url))
       table.put_item(Item = item)
       time.sleep(1/args.writeRate) # to accomodate max write provisioned capacity for table
